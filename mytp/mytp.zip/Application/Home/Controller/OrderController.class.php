<?php

namespace Home\Controller;

class OrderController extends EmptyController{
    public function order()
    {
        $goods = M('goods');
        $gid = I('post.gid');
        $uid = session('id');
        $arr_gid[] = null;
        foreach ($gid as $v) {
            //$arr_gid[$v] = $goods->where(['id' =>$v])->find();
            $rows = $goods->where(['id' =>$v])->find();
            $arr_gid[$v] = $rows;
        }
//        dump($arr_gid);
//        die();
        $data['status']=1;
        $this->ajaxReturn($data);
    }

}
