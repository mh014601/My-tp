<?php
use Think\Page;
use Think\Upload;
function getSonsIdById($id)
{
    $category = M('category');
    static $arr = [];
    // 1.获取孩子的id
    $rows = $category->where(['pid'=>$id])->select();
    if ($rows) {
        // 说明还有孩子 继续查询
        foreach ($rows as $v) {
            $id = $v['id'];  // 查到的孩子的id 4   5  6
            $arr[] = $id;
            getSonsIdById($id);// 4
        }
    }
    return $arr;
}
// 获取所有的商品分类
function getAllCateList(){
    $category = M('category');
    return   $category->order('path asc')->select();
}
// 无限级分类
//$tree = array();
//    foreach ($arr as $val) {
//        if (isset($arr[$val->pid])){//如果等于0 表示顶级目录 但凡pid=0 $arr[0] 不存在走else
//            $arr[$val->pid]->son[] = &$arr[$val->id]; //非顶级分类
//        } else {
//            $tree[] = &$arr[$val->id];
//        }
//    }
//    return $tree;
function gettree($arr)
{
    $tree = array();
    foreach ($arr as $val) {
        if (isset($arr[$val['pid']])){//如果等于0 表示顶级目录 但凡pid=0 $arr[0] 不存在走else
            $arr[$val['pid']]['son'][] = &$arr[$val['id']];
        } else {
            $tree[] = &$arr[$val['id']];
        }
    }
    return $tree;
}
// 处理数组 让数组的键就是数组id
function preArr($arr){
    $temp = [];
    foreach ($arr as $k=>$v){
        //让数组中值里的id=键值
        $temp[$v['id']] = $v;// $temp_arr[1] = ['id'=>1,'cate_name'=>'服装','pid'=>0,'path'=>'1']
    }
    return $temp;
}
function upload(){
    $upload = new Upload();
    $upload->saveName = 'time';
    $upload->maxSize   =     2048000 ;// 设置附件上传大小
    $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
    $upload->rootPath  =      './Public/Admin/upload/'; // 设置附件上传目录
    $info   =   $upload->uploadOne($_FILES['goods_pic']);
//    dump($info);
    if(!$info) {// 上传错误提示错误信息
        $this->error($upload->getError());
    }else{// 上传成功 获取上传文件信息
        echo $info['savepath'].$info['savename'];
    }
}

