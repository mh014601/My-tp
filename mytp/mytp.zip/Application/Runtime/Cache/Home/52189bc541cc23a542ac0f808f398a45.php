<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
    <title>商城</title>
    <meta name="Keywords" content=""/>
    <meta name="description" content="" />
    <script src="/Public/Home1/js/mui.min.js"></script>
    <link href="/Public/Home1/css/mui.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="/Public/Home1/css/style.css" />
    <script type="text/javascript">
        !function(J){function H(){var d=E.getBoundingClientRect().width;var e=(d/7.5>100*B?100*B:(d/7.5<42?42:d/7.5));E.style.fontSize=e+"px",J.rem=e}var G,F=J.document,E=F.documentElement,D=F.querySelector('meta[name="viewport"]'),B=0,A=0;if(D){var y=D.getAttribute("content").match(/initial\-scale=([\d\.]+)/);y&&(A=parseFloat(y[1]),B=parseInt(1/A))}if(!B&&!A){var u=(J.navigator.appVersion.match(/android/gi),J.navigator.appVersion.match(/iphone/gi)),t=J.devicePixelRatio;B=u?t>=3&&(!B||B>=3)?3:t>=2&&(!B||B>=2)?2:1:1,A=1/B}if(E.setAttribute("data-dpr",B),!D){if(D=F.createElement("meta"),D.setAttribute("name","viewport"),D.setAttribute("content","initial-scale="+A+", maximum-scale="+A+", minimum-scale="+A+", user-scalable=no"),E.firstElementChild){E.firstElementChild.appendChild(D)}else{var s=F.createElement("div");s.appendChild(D),F.write(s.innerHTML)}}J.addEventListener("resize",function(){clearTimeout(G),G=setTimeout(H,300)},!1),J.addEventListener("pageshow",function(b){b.persisted&&(clearTimeout(G),G=setTimeout(H,300))},!1),H()}(window);
        if (typeof(M) == 'undefined' || !M){
            window.M = {};
        }
    </script>
</head>
<body>
<header class="mui-bar mui-bar-nav header">
    <a class="mui-action-back mui-icon mui-pull-left" href=""><i class="iconfont"></i></a>
    <h1 class="mui-title">购物车</h1>
</header>
<div class="shopping">
    <div class="shop-group-item">
        <div class="shop-name">
            <input type="checkbox" class="check goods-check shopCheck">
            <h4><a href="#">购物车列表</a></h4>
            <!--<div class="coupons"><span>领券</span><em>|</em><span>编辑</span></div>-->
        </div>
        <ul>
            <li>
                <?php if(is_array($cartList)): foreach($cartList as $key=>$cart): ?><div class="shop-info">
                    <input type="checkbox" class="check goods-check goodsCheck" gid="<?php echo ($cart['gid']); ?>">
                    <div class="shop-info-img"><a href="#"><img src="/Public/Admin/goods/<?php echo ($cart['goods_pic']); ?>"></a></div>
                    <div class="shop-info-text">
                        <h4><?php echo ($cart['goods_name']); ?></h4>
                        <div class="shop-brief"><span>库存:<?php echo ($cart['goods_num']); ?></span><span>商品描述:<?php echo ($cart['goods_detail']); ?></span></div>
                        <div class="shop-price">
                            <div class="shop-pices">￥<b class="price"><?php echo ($cart['goods_price']); ?></b></div>
                            <div class="shop-arithmetic">
                                <a href="javascript:;" class="minus">-</a>
                                <span class="num" value="<?php echo ($cart['num']); ?>"><?php echo ($cart['num']); ?></span>
                                <a href="javascript:;" class="plus">+</a>
                            </div>
                        </div>
                    </div>
                </div><?php endforeach; endif; ?>
            </li>
        </ul>
        <div class="shopPrice">本店总计：￥<span class="shop-total-amount ShopTotal">0.00</span></div>
    </div>
<!--    <div class="h10"></div>-->
</div>
<div class="payment-bar">
    <div class="all-checkbox"><input type="checkbox" class="check goods-check" id="AllCheck">全选</div>
    <div class="shop-total">
        <strong>总价：<i class="total" id="AllTotal">0.00</i></strong>
        <span>减免：123.00</span>
    </div>
<!--    <a href="<?php echo U('Order/order');?>?uid=<?php echo ($uid); ?>&gid=<?php echo ($cart['gid']); ?>&num=<?php echo ($cart['num']); ?>" id="order" class="settlement">结算</a>-->
    <a href="javascript:void(0)" id="order" class="settlement" >结算</a>
</div>
<script type="text/javascript" src="/Public/Home1/js/jquery-1.10.1.min.js" ></script>
<script type="text/javascript" src="/Public/Home1/js/shop.js" ></script>
<script>
    //商品结算
    $('#order').click(function(){
        var num = 0;
        $('.check').each(function () {
            if ($(this).is(':checked')) {
                num++;
            }
        });
        if (num){
            //获取提交商品的id
            var arr_id = [];
            $('.check').each(function () {
                if ($(this).is(':checked')) {
                    id = $(this).attr('gid')
                    //商品Id
                    if(id){
                        arr_id.push(id)
                    }
                }
            });
        }else {
            alert('请选择要买的商品!')
        }
        if(arr_id.length != 0) {
            // var _token = "{csrf_token()}";
            $.post("<?php echo U('Order/order');?>",{gid:arr_id},function (data) {
                if (data.status == 0){
                    // 跳转首页
                    // window.location.href="{{url('/')}}";
                    alert('0');
                }else if(data.status == 1){
                    //跳转支付页面
                    // window.location.href="{{url('Goods/pay')}}?order="+data.order_id+"";
                    alert('1');
                }
            },'json')
        }
    })
</script>
</body>
</html>